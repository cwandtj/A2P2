#!/usr/bin/env python
import time, sys, os
import numpy as np

version = 20171024
nt = time.localtime()
now_time = "## %s_%s_%s_%s:%s:%s \n" % (nt[0],nt[1],nt[2],nt[3],nt[4],nt[5])
usage    = ' Usage: %s [element1],[element2], lattice constant,  h,k,l or POSCAR\n ' % sys.argv[0]
foottext = '\n Thank you\n## Yoon Su Shim (CERU, Korea Institute of Energy Reseach (KIER)) <dbstn145@gmail.com>'
print("## Creaing adsorption structure for ORR using 'PYMATGEN'" )
print("## Version : %s \n" % version)
print(now_time)

### REVISION HISTORY ###############################################################################
##
## 20171017 Updated: Read surface structure from POSCAR format and create adsorption structures
## 20170801 Updated: Combind with ASE for molecule database and with A2P2
##		     Create images of absorbate on slab (fcc) using "PYMATGEN"
## 20170721 Updated: Read and write POSCAR format
## 20170713 Updated: First writing, refered from "npj Computational Materials (2017), 3:14"
##		     Applied for alloy and strained structures
##
####################################################################################################


# Check input file
if len(sys.argv) != 7:
	if len(sys.argv) == 2:
		filename = str(sys.argv[1])
		print('Reading from structure file ... \n')
	else:
		print(usage)
		print(foottext)
		sys.exit(1)

if len(sys.argv) == 7:
	element1  = sys.argv[1]
	element2  = sys.argv[2]
	a0       = float(sys.argv[3])
	MI       = (int(sys.argv[4]), int(sys.argv[5]), int(sys.argv[6]))

# Import statements 
from pymatgen import Structure, Lattice, MPRester, Molecule
from pymatgen.analysis.adsorption import * 
from pymatgen.core.surface import generate_all_slabs 
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer 
from matplotlib import pyplot as plt 
from pymatgen.io.vasp import Poscar
from pymatgen.core import IStructure

#% matplotlib inline 
# Note that you must provide your own API Key, which can 
# be accessed via the Dashboard at materialsproject.org 
#mpr = MPRester()

def read_POSCAR(filename):
	f = open(filename)
	lines	= f.readlines()
	nlines	= len(lines)
	lattice_lines  = lines[2:5]
	species_lines  = lines[5].split()
	nspecies     = lines[6].split()
	position_lines = lines[8:nlines]

	lattice = [];position = [];species = []

	i= 0
	while i< len(species_lines):
		for ns in range(int(nspecies[i])):
			species.append(species_lines[i])
		i+=1

	for line in lattice_lines:
		line = line.split()
		line2 = []
		for li in line:
			line2.append(float(li))
		lattice.append(line2)

	for line in position_lines:
		line = line.split()[0:3]
		line2 =[]
		for li in line:
			line2.append(float(li))
		position.append(line2)

	return species, nspecies, lattice, position

if len(sys.argv) ==7:
	#a0_x = 3.3; a0_y = 4.5
	#lattice = Lattice([[a0_x,0,0],[0,a0_y,0],[0,0, a0_x]]) # To describe uniaxial strain
	lattice = Lattice.cubic(a0)
	#structure = Structure(lattice, [element1,element1,element1,element2], [[0, 0, 0], [0.5, 0.5, 0.0],[0, 0.5,0.5],[0.5,0,0.5]])
	structure = Structure.from_spacegroup("Fm-3m", lattice, [element1, element2], [[0, 0, 0], [0.5, 0.5, 0.5]])
	slabs = generate_all_slabs(structure, max_index=1, min_slab_size=8.0, min_vacuum_size=10.0)
	metal_ml = [slab for slab in slabs if slab.miller_index==MI][0]

if len(sys.argv) ==2: 
	#metal_ml = IStructure.from_file(filename)
	#lattice = metal_ml.lattice.matrix
	species, nspecies, lattice, positions = read_POSCAR(filename)
	metal_ml = Structure(lattice, species, positions)
	
#print 'Input structure: \n',metal_ml
asf_metal_ml = AdsorbateSiteFinder(metal_ml) 
#print 'ASF structure: \n',asf_metal_ml
ads_sites = asf_metal_ml.find_adsorption_sites() 
print 'Adsorption sites: \n',ads_sites
print 'Number of sites: ',len(ads_sites['all'])

#fig = plt.figure() 
#ax = fig.add_subplot(111) 
#plot_slab(metal_ml, ax, adsorption_sites=True)

if len(sys.argv) == 2:
	#plt.savefig('slab_%s_site.png' % filename)
	Poscar(metal_ml).write_file('%s_output.vasp' % filename )

if len(sys.argv) == 7:
	#plt.savefig('slab_%s%s_site.png' % (element1,element2))
	Poscar(metal_ml).write_file('%s%s_%i%i%i_output.vasp' % (element1, element2, MI[0],MI[1],MI[2]))

from ase.build import molecule as asemole

def molecule_ase_to_pymatgen(species):
	# from ASE database import molecule structures
	molecule_ase      = asemole(species)
	molecule_position = molecule_ase.get_positions()
	molecule_species  = molecule_ase.get_chemical_symbols()
	molecule_name     = ''

	for species_name in molecule_species:
		molecule_name +=species_name

	molecule	  = Molecule(molecule_name, molecule_position)

	return molecule

h    = Molecule("H", [[0,0,0]])
o    = Molecule("O", [[0,0,0]])
o2   = molecule_ase_to_pymatgen('O2')
oh   = molecule_ase_to_pymatgen('OH')
#o2  = Molecule("OO", [[0, 0, 0],[0,0,1.2]]) 
#oh  = Molecule("OH", [[0, 0, 0], [-0.793, 0.384, 0.422]])
ooh  = Molecule("OOH", [[0, 0, 0], [-1.067, -0.403, 0.796], [-0.696, -0.272, 1.706]])
h2o2 = molecule_ase_to_pymatgen('H2O2')
h2o  = molecule_ase_to_pymatgen('H2O')

adsorbates =[h,o,o2,oh,ooh,h2o2,h2o] 

#save output
output = {'nsite':len(ads_sites['all']),'nads':len(adsorbates)}
ads_list = []
for adsorbate in adsorbates:
	if len(sys.argv) == 2:
		ads_structs = asf_metal_ml.generate_adsorption_structures(adsorbate, repeat=[1, 1, 1], reorient=True)
	else :
		ads_structs = asf_metal_ml.generate_adsorption_structures(adsorbate, reorient=True)
	nads= len(ads_structs)
#	print ads_structs
	NAME = [SPECIES.name for SPECIES  in adsorbate.species]
	nnn=''
	for nn in NAME:
		nnn += nn
	ads_list.append(nnn)
	
	i=0
	while (i < nads):
		#fig = plt.figure() 
		#ax = fig.add_subplot(111) 
		#plot_slab(ads_structs[i], ax, adsorption_sites=False, decay=0.09)
		print nnn, i,'/',nads
		if len(sys.argv) == 2:
			#plt.savefig('slab_%s_ads%s_site%i.png' % (filename,nnn,i))       
			Poscar(ads_structs[i]).write_file('%s_ads%s_site%i.vasp' % (filename,nnn,i))
		if len(sys.argv) == 7:
			#plt.savefig('slab_%s%s_ads%s_site%i.png' % (element1,element2,nnn,i))
			Poscar(ads_structs[i]).write_file('%s%s_ads%s_site%i.vasp' % (element1,element2,nnn,i))
		# Save each structure
		output['%s_%i' % (nnn,i+1)] = Poscar(ads_structs[i]).get_string()
		i+=1
	#plt.show()
output['ads']=ads_list

#os.system('python a2p2.py')  # 171024_YS
import glob,our_module  # 171024_YS
poscar_files = glob.glob('*.vasp') # 171024_YS
for file in poscar_files:  # 171024_YS
        our_module.create_compound_folder_poscar(file)   # 171024_YS

os.system('mkdir temp')
os.system('mv *.vasp temp/')

if len(sys.argv) == 2:
	if os.path.isdir('slab_'+filename) :
		os.system("rm -r slab_"+filename)
	os.system('mv temp slab_%s' % filename)
if len(sys.argv) == 7:
	if os.path.isdir('%s%s_%i%i%i' % (element1,element2,MI[0],MI[1],MI[2])) :
		os.system("rm -r %s%s_%i%i%i" % (element1,element2,MI[0],MI[1],MI[2]))
	os.system('mv temp %s%s_%i%i%i' % (element1,element2,MI[0],MI[1],MI[2]))

#print output
